scp target/microchassis-connection-1.0.jar root@172.20.3.71:/u01/thangnq16/vocs/abm-runtime/app/abm/lib
scp target/microchassis-connection-1.0.jar root@172.20.3.71:/u01/thangnq16/vocs/cgw-runtime/app/cgw/lib
scp target/microchassis-connection-1.0.jar root@172.20.3.71:/u01/thangnq16/vocs/chp-cc-runtime/app/chp-cc/lib
scp target/microchassis-connection-1.0.jar root@172.20.3.71:/u01/thangnq16/vocs/pcf-sm-runtime/app/pcf-sm/lib
