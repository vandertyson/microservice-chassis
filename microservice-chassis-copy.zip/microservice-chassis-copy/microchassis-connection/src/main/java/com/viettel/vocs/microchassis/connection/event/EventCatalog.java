package com.viettel.vocs.microchassis.connection.event;

public interface EventCatalog {
	int getCode();
}
