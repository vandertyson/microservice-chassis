package com.viettel.vocs.microchassis.connection.loadbalancing.traffic.monitor;

/**
 * @author tiennn18
 */
public class ConnectionBlocker {
}
