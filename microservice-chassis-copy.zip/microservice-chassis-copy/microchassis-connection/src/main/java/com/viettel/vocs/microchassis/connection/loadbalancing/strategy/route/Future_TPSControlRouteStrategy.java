package com.viettel.vocs.microchassis.connection.loadbalancing.strategy.route;

/**
 * @author tiennn18
 */
//public class Future_TPSControlRouteStrategy extends FrontPressureRouteStrategy {
//	/**
//	 * can combine with CenterLBR, push down TPS config for each conn
//	 *    WARNING: this may cause wave TPS on CenterLBR map
//	 * more effective CPU than TPSCC Backpressure
//	 *
//	 * @param configure
//	 * @param connections
//	 */
//
//}
