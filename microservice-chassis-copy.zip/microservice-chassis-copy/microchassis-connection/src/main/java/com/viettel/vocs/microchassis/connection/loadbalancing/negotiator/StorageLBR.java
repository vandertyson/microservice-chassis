package com.viettel.vocs.microchassis.connection.loadbalancing.negotiator;

/**
 * @author tiennn18
 */

/**
 * negotiate over centerlized server like Zookeeper
 * client act as parallel simultaneously resolver, with vary version
 * 	this led to un-convergable situation that need local self continuity
 */
