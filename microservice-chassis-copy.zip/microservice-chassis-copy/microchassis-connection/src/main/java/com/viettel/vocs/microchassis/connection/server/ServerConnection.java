package com.viettel.vocs.microchassis.connection.server;

/**
 * @author tiennn18
 */
public abstract class ServerConnection {
}
