package com.viettel.vocs.microchassis.connection.loadbalancing.configure;

/**
 * @author tiennn18
 */
public class LLC extends FrontConfigure {

}
