package com.viettel.vocs.microchassis.connection.loadbalancing.configure;

public class LCC extends FrontConfigure {


	// ================ config .yml above ===============
}
