package com.viettel.vocs.microchassis.connection.loadbalancing.traffic.mode;

/**
 * @author tiennn18
 */
public interface APIKPI {
}
