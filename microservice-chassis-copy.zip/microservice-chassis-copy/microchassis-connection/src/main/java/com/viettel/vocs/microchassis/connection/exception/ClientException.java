package com.viettel.vocs.microchassis.connection.exception;

public class ClientException extends Exception {

    public ClientException(String message) {
        super(message);
    }
}
