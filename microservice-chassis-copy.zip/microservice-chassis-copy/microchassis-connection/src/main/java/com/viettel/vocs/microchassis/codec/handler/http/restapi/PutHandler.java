package com.viettel.vocs.microchassis.codec.handler.http.restapi;

public interface PutHandler<ReplyCtx> {
	void putHandle(ReplyCtx serverCtx);
}
