package com.viettel.vocs.microchassis.connection.exception;

import java.security.InvalidParameterException;

/**
 * @author tiennn18
 */
public class UpdateSiteException extends InvalidParameterException {
	public UpdateSiteException(String msg) {
		super(msg);
	}
}
