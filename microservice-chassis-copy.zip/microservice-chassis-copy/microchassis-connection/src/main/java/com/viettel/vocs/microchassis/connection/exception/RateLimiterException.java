package com.viettel.vocs.microchassis.connection.exception;

public class RateLimiterException extends Exception {
    public RateLimiterException(String message) {
        super(message);
    }
}
