openssl req -nodes -x509 -newkey rsa:4096 -keyout key_nodes.pem -out cert_nodes.pem -days 365
