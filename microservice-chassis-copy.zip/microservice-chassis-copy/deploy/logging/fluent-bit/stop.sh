kubectl delete -f deploy/logging/fluent-bit/service-account.yaml
kubectl delete -f deploy/logging/fluent-bit/config-map.yaml
kubectl delete -f deploy/logging/fluent-bit/fluent-bit.yaml