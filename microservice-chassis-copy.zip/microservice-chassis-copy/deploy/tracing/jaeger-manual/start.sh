kubectl apply -f deploy/tracing/jaeger-manual/config-map.yaml
kubectl apply -f deploy/tracing/jaeger-manual/jaeger-production.yaml