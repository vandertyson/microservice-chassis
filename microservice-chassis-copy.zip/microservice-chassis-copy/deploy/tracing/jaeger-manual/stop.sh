kubectl delete -f deploy/tracing/jaeger-manual/config-map.yaml
kubectl delete -f deploy/tracing/jaeger-manual/jaeger-production.yaml