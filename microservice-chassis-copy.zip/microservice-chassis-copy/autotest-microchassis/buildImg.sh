sudo docker build -t docker-registry:4000/autotest-microchassis:latest -f Dockerfile .
sudo docker push docker-registry:4000/autotest-microchassis:latest