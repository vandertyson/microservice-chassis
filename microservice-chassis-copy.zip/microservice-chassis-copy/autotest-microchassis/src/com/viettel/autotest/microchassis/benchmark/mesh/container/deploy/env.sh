#!/bin/bash
MCS=/home/vht/Projecs/javawork/microservice-chassis-1m

CON_PATH=$MCS/microchassis-connection
MESH_PATH=$MCS/microchassis-demo
TARGET_PATH=$MESH_PATH/target
MINION_PATH=$MESH_PATH/src/com/viettel/vocs/microchassis/tiennn18/minions

KUBE_NS=tiennn18-mesh
KUBE_CTX=pat01

KUBE_NS=tiennn18-mesh
KUBE_CTX=pat01
