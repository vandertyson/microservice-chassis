package com.viettel.autotest.microchassis.connection.config;

public interface AutoTestClientConfig {
	boolean isSendSync();
}
