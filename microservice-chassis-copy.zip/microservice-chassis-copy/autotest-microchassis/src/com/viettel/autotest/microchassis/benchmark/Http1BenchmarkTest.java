package com.viettel.autotest.microchassis.benchmark;

/**
 * @author tiennn18
 */
public class Http1BenchmarkTest {

}
