package com.viettel.autotest.microchassis.benchmark.mesh.DB;

public interface DBNode {

	void dbFactorWait(int ndb);
}
