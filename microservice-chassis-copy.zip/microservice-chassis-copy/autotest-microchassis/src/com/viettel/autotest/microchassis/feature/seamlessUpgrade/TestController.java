package com.viettel.autotest.microchassis.feature.seamlessUpgrade;

/**
 * @author tiennn18
 */
public class TestController {
}
