test chassis gom

- test chuc nang (feature): chua tung bai test rieng le cho chuc nang, dinh nghia echo client va server chuan
- test hieu nang (benchmark): extend tu feature class
- test tich hop (compatible): extend tu feature class

